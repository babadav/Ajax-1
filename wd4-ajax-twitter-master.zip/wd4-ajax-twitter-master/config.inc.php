<?php

$twitteruser = "babadav1";
$consumerkey = "vQcl2hkYFWwGMBjxpKl0M002e";
$consumersecret = "GKZYKmlx2JRaDgVhmq5GtIfvy1aFRJOkJqfgtAcbaY7EVGOdV3";
$accesstoken = "240083180-rhV3yAZpcTXiyt2t7ldYzHvfDMgD8scsKgHq8tAm";
$accesstokensecret = "QdILb748NJLLVlBKhoBVYsvLBqRDqw7T40dGnPuw8ikjS";